"""
Dogleg Severity (DLS) Analysis for Directional Drilling
========================================================
Computes DLS using the Minimum Curvature Method (industry standard),
along with wellbore survey analysis, 3D trajectory plotting, and
tortuosity reporting.

Units: depths in meters (or feet), angles in degrees, DLS in °/30m (or °/100ft)
"""

import math
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from dataclasses import dataclass, field
from typing import List, Tuple, Optional
import csv
import sys


# ─────────────────────────────────────────────
# Data structures
# ─────────────────────────────────────────────

@dataclass
class SurveyStation:
    """Represents a single directional survey measurement."""
    md: float          # Measured Depth
    inc: float         # Inclination (degrees)
    azi: float         # Azimuth (degrees)
    tvd: float = 0.0   # True Vertical Depth (calculated)
    north: float = 0.0 # North displacement (calculated)
    east: float = 0.0  # East displacement (calculated)
    dls: float = 0.0   # Dogleg Severity °/30m (calculated)
    dl: float = 0.0    # Dogleg angle (degrees) (calculated)


@dataclass
class WellSurvey:
    """Container for a complete well survey dataset."""
    name: str
    unit: str = "metric"   # "metric" or "imperial"
    stations: List[SurveyStation] = field(default_factory=list)

    @property
    def dls_interval(self) -> float:
        """Normalization interval for DLS (30m metric, 100ft imperial)."""
        return 30.0 if self.unit == "metric" else 100.0

    @property
    def unit_label(self) -> str:
        return "m" if self.unit == "metric" else "ft"


# ─────────────────────────────────────────────
# Core DLS Calculations
# ─────────────────────────────────────────────

def deg2rad(d: float) -> float:
    return math.radians(d)


def rad2deg(r: float) -> float:
    return math.degrees(r)


def dogleg_angle(inc1: float, azi1: float, inc2: float, azi2: float) -> float:
    """
    Compute the dogleg angle (β) between two survey stations using the
    spherical law of cosines.

    Parameters
    ----------
    inc1, azi1 : inclination and azimuth at upper station (degrees)
    inc2, azi2 : inclination and azimuth at lower station (degrees)

    Returns
    -------
    dogleg angle in degrees
    """
    i1, a1 = deg2rad(inc1), deg2rad(azi1)
    i2, a2 = deg2rad(inc2), deg2rad(azi2)

    cos_dl = (math.cos(i1) * math.cos(i2) +
              math.sin(i1) * math.sin(i2) * math.cos(a2 - a1))

    # Clamp to [-1, 1] to guard against floating-point noise
    cos_dl = max(-1.0, min(1.0, cos_dl))
    return rad2deg(math.acos(cos_dl))


def dogleg_severity(dl_deg: float, delta_md: float, interval: float = 30.0) -> float:
    """
    Normalise the dogleg angle to a standard interval (°/30m or °/100ft).

    Parameters
    ----------
    dl_deg   : dogleg angle in degrees
    delta_md : measured depth increment between stations
    interval : normalisation length (default 30 m)
    """
    if delta_md <= 0:
        return 0.0
    return dl_deg * (interval / delta_md)


def minimum_curvature(station_a: SurveyStation,
                      station_b: SurveyStation,
                      interval: float = 30.0) -> Tuple[float, float, float, float, float, float]:
    """
    Minimum Curvature Method — industry-standard wellbore position calculation.

    Returns
    -------
    (delta_tvd, delta_north, delta_east, dogleg_deg, dls, rf)
    """
    delta_md = station_b.md - station_a.md
    if delta_md == 0:
        return 0.0, 0.0, 0.0, 0.0, 0.0, 1.0

    i1, a1 = deg2rad(station_a.inc), deg2rad(station_a.azi)
    i2, a2 = deg2rad(station_b.inc), deg2rad(station_b.azi)

    dl = dogleg_angle(station_a.inc, station_a.azi, station_b.inc, station_b.azi)
    dl_rad = deg2rad(dl)

    # Ratio Factor (RF)
    if dl_rad == 0:
        rf = 1.0
    else:
        rf = (2.0 / dl_rad) * math.tan(dl_rad / 2.0)

    half_md = delta_md / 2.0

    delta_tvd   = half_md * (math.cos(i1) + math.cos(i2)) * rf
    delta_north = half_md * (math.sin(i1) * math.cos(a1) + math.sin(i2) * math.cos(a2)) * rf
    delta_east  = half_md * (math.sin(i1) * math.sin(a1) + math.sin(i2) * math.sin(a2)) * rf

    dls = dogleg_severity(dl, delta_md, interval)

    return delta_tvd, delta_north, delta_east, dl, dls, rf


# ─────────────────────────────────────────────
# Survey Processing
# ─────────────────────────────────────────────

def process_survey(survey: WellSurvey) -> WellSurvey:
    """
    Compute TVD, North, East, and DLS for every station in the survey.
    The first station is treated as the reference (usually surface).
    """
    if not survey.stations:
        return survey

    # Initialise first station
    survey.stations[0].tvd = 0.0
    survey.stations[0].north = 0.0
    survey.stations[0].east = 0.0
    survey.stations[0].dls = 0.0
    survey.stations[0].dl = 0.0

    for i in range(1, len(survey.stations)):
        prev = survey.stations[i - 1]
        curr = survey.stations[i]

        d_tvd, d_north, d_east, dl, dls, _ = minimum_curvature(
            prev, curr, interval=survey.dls_interval
        )

        curr.tvd   = prev.tvd   + d_tvd
        curr.north = prev.north + d_north
        curr.east  = prev.east  + d_east
        curr.dl    = dl
        curr.dls   = dls

    return survey


# ─────────────────────────────────────────────
# Analysis & Reporting
# ─────────────────────────────────────────────

def summarise(survey: WellSurvey) -> dict:
    """Return key statistics for the survey."""
    dls_values = [s.dls for s in survey.stations[1:]]
    inc_values = [s.inc for s in survey.stations]

    if not dls_values:
        return {}

    max_dls_station = max(survey.stations[1:], key=lambda s: s.dls)
    last = survey.stations[-1]

    return {
        "well_name":        survey.name,
        "unit":             survey.unit,
        "stations":         len(survey.stations),
        "max_md":           last.md,
        "final_tvd":        last.tvd,
        "final_north":      last.north,
        "final_east":       last.east,
        "max_dls":          max(dls_values),
        "max_dls_md":       max_dls_station.md,
        "avg_dls":          sum(dls_values) / len(dls_values),
        "max_inc":          max(inc_values),
        "departure":        math.sqrt(last.north**2 + last.east**2),
        "tortuosity_index": sum(s.dl for s in survey.stations[1:]),
    }


def print_report(survey: WellSurvey) -> None:
    """Print a formatted ASCII report to stdout."""
    s = summarise(survey)
    ul = survey.unit_label
    iv = survey.dls_interval

    print("=" * 72)
    print(f"  DOGLEG SEVERITY ANALYSIS REPORT  —  {s['well_name']}")
    print("=" * 72)
    print(f"  System of units  : {survey.unit.upper()} ({ul})")
    print(f"  Survey stations  : {s['stations']}")
    print(f"  Max Measured Depth: {s['max_md']:.2f} {ul}")
    print(f"  Final TVD        : {s['final_tvd']:.2f} {ul}")
    print(f"  Final North      : {s['final_north']:.2f} {ul}")
    print(f"  Final East       : {s['final_east']:.2f} {ul}")
    print(f"  Horizontal Depart: {s['departure']:.2f} {ul}")
    print("-" * 72)
    print(f"  Max DLS          : {s['max_dls']:.3f} °/{iv}{ul}  @ MD {s['max_dls_md']:.2f} {ul}")
    print(f"  Avg DLS          : {s['avg_dls']:.3f} °/{iv}{ul}")
    print(f"  Max Inclination  : {s['max_inc']:.2f}°")
    print(f"  Tortuosity Index : {s['tortuosity_index']:.2f}° (cumulative dogleg)")
    print("=" * 72)
    print()

    # Per-station table
    header = (f"{'MD':>10} {'INC':>8} {'AZI':>8} {'TVD':>10} "
              f"{'NORTH':>10} {'EAST':>10} {'DL°':>7} {'DLS':>10}")
    print(header)
    print("-" * 72)
    for st in survey.stations:
        flag = " ◀ MAX DLS" if st.dls == s['max_dls'] and st.dls > 0 else ""
        print(f"{st.md:10.2f} {st.inc:8.3f} {st.azi:8.3f} {st.tvd:10.3f} "
              f"{st.north:10.3f} {st.east:10.3f} {st.dl:7.3f} {st.dls:10.4f}{flag}")
    print()


# ─────────────────────────────────────────────
# Plotting
# ─────────────────────────────────────────────

def plot_dls_profile(survey: WellSurvey, threshold: float = 3.0,
                     save_path: Optional[str] = None) -> None:
    """
    Plot DLS vs MD with a severity threshold line and inclination overlay.
    """
    mds  = [s.md  for s in survey.stations[1:]]
    dls  = [s.dls for s in survey.stations[1:]]
    incs = [s.inc for s in survey.stations]

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(11, 8), sharex=True,
                                   gridspec_kw={"hspace": 0.08})
    fig.suptitle(f"Dogleg Severity Analysis — {survey.name}",
                 fontsize=14, fontweight="bold")

    # ── DLS plot ──
    colors = ["#e74c3c" if d > threshold else "#2ecc71" for d in dls]
    ax1.bar(mds, dls, width=[(mds[i] - mds[i-1]) if i > 0 else mds[0]
                              for i in range(len(mds))],
            color=colors, alpha=0.75, align="edge", linewidth=0.3, edgecolor="white")
    ax1.axhline(threshold, color="#e74c3c", linestyle="--", linewidth=1.4,
                label=f"DLS threshold ({threshold} °/{survey.dls_interval}{survey.unit_label})")
    ax1.set_ylabel(f"DLS (°/{survey.dls_interval}{survey.unit_label})", fontsize=11)
    ax1.legend(fontsize=9)
    ax1.grid(axis="y", alpha=0.3)
    ax1.set_ylim(bottom=0)

    # Annotate max DLS
    max_dls = max(dls)
    max_md  = mds[dls.index(max_dls)]
    ax1.annotate(f"Max {max_dls:.2f}",
                 xy=(max_md, max_dls), xytext=(max_md + 50, max_dls + 0.3),
                 arrowprops=dict(arrowstyle="->", color="black"),
                 fontsize=8, color="#c0392b")

    # ── Inclination plot ──
    ax2.plot([s.md for s in survey.stations], incs,
             color="#3498db", linewidth=1.8, marker="o", markersize=3)
    ax2.set_xlabel(f"Measured Depth ({survey.unit_label})", fontsize=11)
    ax2.set_ylabel("Inclination (°)", fontsize=11)
    ax2.grid(alpha=0.3)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"  [Plot saved → {save_path}]")
    else:
        plt.show()
    plt.close()


def plot_3d_trajectory(survey: WellSurvey, save_path: Optional[str] = None) -> None:
    """
    3D wellbore trajectory coloured by DLS magnitude.
    """
    north = [s.north for s in survey.stations]
    east  = [s.east  for s in survey.stations]
    tvd   = [-s.tvd  for s in survey.stations]  # invert TVD for depth-down view
    dls   = [s.dls   for s in survey.stations]

    fig = plt.figure(figsize=(10, 8))
    ax  = fig.add_subplot(111, projection="3d")

    # Colour segments by DLS
    dls_arr = np.array(dls)
    norm = plt.Normalize(dls_arr.min(), dls_arr.max())
    cmap = plt.cm.RdYlGn_r

    for i in range(1, len(north)):
        c = cmap(norm(dls[i]))
        ax.plot([east[i-1], east[i]], [north[i-1], north[i]], [tvd[i-1], tvd[i]],
                color=c, linewidth=2.5)

    sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
    sm.set_array([])
    cbar = plt.colorbar(sm, ax=ax, pad=0.1, shrink=0.6)
    cbar.set_label(f"DLS (°/{survey.dls_interval}{survey.unit_label})", fontsize=9)

    # Mark surface and TD
    ax.scatter(*[east[0]], *[north[0]], *[tvd[0]],
               color="green", s=60, zorder=5, label="Surface")
    ax.scatter(*[east[-1]], *[north[-1]], *[tvd[-1]],
               color="red", s=60, zorder=5, label="TD")

    ax.set_xlabel(f"East ({survey.unit_label})")
    ax.set_ylabel(f"North ({survey.unit_label})")
    ax.set_zlabel(f"TVD ({survey.unit_label})")
    ax.set_title(f"3D Wellbore Trajectory — {survey.name}\n(coloured by DLS)",
                 fontsize=12)
    ax.legend()

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"  [Plot saved → {save_path}]")
    else:
        plt.show()
    plt.close()


# ─────────────────────────────────────────────
# CSV I/O helpers
# ─────────────────────────────────────────────

def load_from_csv(filepath: str, name: str = "Well", unit: str = "metric") -> WellSurvey:
    """
    Load survey data from a CSV file.
    Expected columns (case-insensitive): md, inc, azi
    """
    survey = WellSurvey(name=name, unit=unit)
    with open(filepath, newline="") as f:
        reader = csv.DictReader(f)
        headers = [h.lower().strip() for h in reader.fieldnames]
        for row in reader:
            row_lower = {k.lower().strip(): v for k, v in row.items()}
            try:
                station = SurveyStation(
                    md=float(row_lower["md"]),
                    inc=float(row_lower["inc"]),
                    azi=float(row_lower["azi"]),
                )
                survey.stations.append(station)
            except (KeyError, ValueError) as e:
                print(f"  [Warning] Skipping row: {e}")
    return survey


def export_results_csv(survey: WellSurvey, filepath: str) -> None:
    """Export processed survey (with TVD, DLS, etc.) to CSV."""
    ul = survey.unit_label
    iv = survey.dls_interval
    with open(filepath, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            f"MD ({ul})", f"Inc (°)", f"Azi (°)", f"TVD ({ul})",
            f"North ({ul})", f"East ({ul})", "DL (°)", f"DLS (°/{iv}{ul})"
        ])
        for s in survey.stations:
            writer.writerow([
                f"{s.md:.3f}", f"{s.inc:.3f}", f"{s.azi:.3f}",
                f"{s.tvd:.3f}", f"{s.north:.3f}", f"{s.east:.3f}",
                f"{s.dl:.4f}", f"{s.dls:.4f}"
            ])
    print(f"  [Results exported → {filepath}]")


# ─────────────────────────────────────────────
# Built-in example dataset
# ─────────────────────────────────────────────

def build_example_survey() -> WellSurvey:
    """
    Realistic S-shaped directional well survey (metric units).
    Represents a typical offshore well: build → hold → drop section.
    """
    raw = [
        # MD,    Inc,   Azi
        (0,      0.0,   0.0),
        (100,    0.5,   10.0),
        (300,    2.0,   15.0),
        (500,    8.0,   20.0),
        (700,   18.0,   22.0),
        (900,   30.0,   25.0),
        (1100,  42.0,   28.0),
        (1300,  52.0,   30.0),
        (1500,  60.0,   32.0),   # Peak inclination build
        (1700,  60.0,   35.0),   # Tangent section
        (1900,  60.0,   38.0),
        (2100,  60.0,   40.0),
        (2300,  60.0,   40.0),
        (2500,  50.0,   42.0),   # Drop section
        (2700,  38.0,   44.0),
        (2900,  25.0,   45.0),
        (3100,  12.0,   46.0),
        (3300,   5.0,   47.0),
        (3500,   2.0,   48.0),
        (3700,   1.0,   48.0),
        (3900,   0.5,   48.0),
    ]
    survey = WellSurvey(name="Example S-Curve Well (Offshore)", unit="metric")
    for md, inc, azi in raw:
        survey.stations.append(SurveyStation(md=md, inc=inc, azi=azi))
    return survey


# ─────────────────────────────────────────────
# Standalone utility — single interval DLS
# ─────────────────────────────────────────────

def quick_dls(md1: float, inc1: float, azi1: float,
              md2: float, inc2: float, azi2: float,
              unit: str = "metric") -> dict:
    """
    Quick DLS calculation for a single interval between two survey stations.

    Parameters
    ----------
    md1, inc1, azi1 : upper station (MD in same units as interval)
    md2, inc2, azi2 : lower station
    unit            : 'metric' (°/30m) or 'imperial' (°/100ft)

    Returns
    -------
    dict with dogleg_deg, dls, delta_md, rf
    """
    interval = 30.0 if unit == "metric" else 100.0
    a = SurveyStation(md=md1, inc=inc1, azi=azi1)
    b = SurveyStation(md=md2, inc=inc2, azi=azi2)
    d_tvd, d_north, d_east, dl, dls, rf = minimum_curvature(a, b, interval)
    return {
        "delta_md":    md2 - md1,
        "dogleg_deg":  dl,
        "dls":         dls,
        "rf":          rf,
        "delta_tvd":   d_tvd,
        "delta_north": d_north,
        "delta_east":  d_east,
    }


# ─────────────────────────────────────────────
# Main entry point
# ─────────────────────────────────────────────

if __name__ == "__main__":
    # ── Option A: run with built-in example ──
    if len(sys.argv) == 1:
        print("\nRunning built-in example survey...\n")
        survey = build_example_survey()

    # ── Option B: load CSV from command line ──
    elif len(sys.argv) >= 2:
        csv_path = sys.argv[1]
        well_name = sys.argv[2] if len(sys.argv) > 2 else "Well"
        unit      = sys.argv[3] if len(sys.argv) > 3 else "metric"
        print(f"\nLoading survey from: {csv_path}\n")
        survey = load_from_csv(csv_path, name=well_name, unit=unit)

    # Process and report
    process_survey(survey)
    print_report(survey)

    # Export results
    export_results_csv(survey, "dls_results.csv")

    # Plots (comment out if running headless)
    plot_dls_profile(survey, threshold=3.0, save_path="dls_profile.png")
    plot_3d_trajectory(survey,               save_path="dls_trajectory_3d.png")

    # ── Quick single-interval example ──
    print("\n── Quick Single-Interval DLS ──")
    result = quick_dls(
        md1=900, inc1=30.0, azi1=25.0,
        md2=1100, inc2=42.0, azi2=28.0,
        unit="metric"
    )
    for k, v in result.items():
        print(f"  {k:15s}: {v:.4f}")
